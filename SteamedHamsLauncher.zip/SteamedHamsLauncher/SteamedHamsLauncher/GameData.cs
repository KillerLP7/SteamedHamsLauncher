﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SteamedHamsLauncher
{
    public class GameData
    {
        //SteamAPI -> AppDetails -> GameData
        //Die Daten die man vom Spiel nehmen kann
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("short_description")]
        public string ShortDescription { get; set; }

        // Weiter Daten entnehmen ...
    }
}
