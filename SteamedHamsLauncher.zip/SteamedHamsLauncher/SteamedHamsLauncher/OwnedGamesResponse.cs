﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SteamedHamsLauncher
{
    public class OwnedGamesResponse
    {
        [JsonProperty("response")]
        public ResponseData Response { get; set; }
    }

    public class ResponseData
    {
        [JsonProperty("game_count")]
        public int GameCount { get; set; }

        [JsonProperty("games")]
        public List<Game> Games { get; set; }
    }

    public class Game
    {
        [JsonProperty("appid")]
        public int AppId { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("playtime_2weeks")]
        public int PlaytimeTwoWeeks { get; set; }

        [JsonProperty("playtime_forever")]
        public int PlaytimeForever { get; set; }

        [JsonProperty("img_icon_url")]
        public string IconUrl { get; set; }

        [JsonProperty("rtime_last_played")]
        public int LastPlayed { get; set; }
    }
}
